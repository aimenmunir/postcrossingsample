
# Postcrossing Tab Sorter (Firefox)

Sort all open Postcrossing postcard tabs in the **current window** by their numeric ID (ascending).

Examples order:
- https://www.postcrossing.com/postcards/CL-34269
- https://www.postcrossing.com/postcards/CN-4087990
- https://www.postcrossing.com/postcards/US-11797804

## Install (Temporary)

1. Open `about:debugging#/runtime/this-firefox`
2. Click **Load Temporary Add-on…**
3. Select the `manifest.json` file from this folder.

You’ll see a toolbar button. Click it to sort, or press **Ctrl+Shift+Y**.

## How it works

- Matches URLs like `/postcards/CC-NUMBER`.
- Sort key: numeric ID ascending; ties broken by country code (A–Z), then original tab order.
- Tabs are re-grouped to a contiguous block starting at the smallest original index among the matched tabs.
